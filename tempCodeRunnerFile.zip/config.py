# config.py
class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '84325251Flap@'
    MYSQL_DB = 'school'
